INSERT INTO GTWPEST.dbo.TargetRate (Detail) VALUES ('已确认');
INSERT INTO GTWPEST.dbo.TargetRate (Detail) VALUES ('高');
INSERT INTO GTWPEST.dbo.TargetRate (Detail) VALUES ('中');
INSERT INTO GTWPEST.dbo.TargetRate (Detail) VALUES ('低');
INSERT INTO GTWPEST.dbo.TargetRate (Detail) VALUES ('不确定');
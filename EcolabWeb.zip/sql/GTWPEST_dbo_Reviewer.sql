INSERT INTO GTWPEST.dbo.Reviewer (Name) VALUES ('Alan Xu');
INSERT INTO GTWPEST.dbo.Reviewer (Name) VALUES ('Cherry Chen');
INSERT INTO GTWPEST.dbo.Reviewer (Name) VALUES ('Norman Li');
INSERT INTO GTWPEST.dbo.Reviewer (Name) VALUES ('Yi Hui');
INSERT INTO GTWPEST.dbo.Reviewer (Name) VALUES ('Ryan Wu');
INSERT INTO GTWPEST.dbo.Reviewer (Name) VALUES ('Su Heng');
INSERT INTO GTWPEST.dbo.Reviewer (Name) VALUES ('Ringo');
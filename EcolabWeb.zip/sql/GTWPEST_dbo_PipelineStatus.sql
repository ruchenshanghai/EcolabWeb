INSERT INTO GTWPEST.dbo.PipelineStatus (Detail) VALUES ('30Day');
INSERT INTO GTWPEST.dbo.PipelineStatus (Detail) VALUES ('60Day');
INSERT INTO GTWPEST.dbo.PipelineStatus (Detail) VALUES ('90Day');
INSERT INTO GTWPEST.dbo.PipelineStatus (Detail) VALUES ('>90Day');
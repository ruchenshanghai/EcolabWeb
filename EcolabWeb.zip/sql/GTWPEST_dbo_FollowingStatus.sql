INSERT INTO GTWPEST.dbo.FollowingStatus (Detail) VALUES ('Follow Up-继续跟进');
INSERT INTO GTWPEST.dbo.FollowingStatus (Detail) VALUES ('Proposal-提出方案');
INSERT INTO GTWPEST.dbo.FollowingStatus (Detail) VALUES ('Bidding-投标');
INSERT INTO GTWPEST.dbo.FollowingStatus (Detail) VALUES ('Contract-合同待签署');
INSERT INTO GTWPEST.dbo.FollowingStatus (Detail) VALUES ('Gained-已获得');
INSERT INTO GTWPEST.dbo.FollowingStatus (Detail) VALUES ('Audit-审计');
INSERT INTO GTWPEST.dbo.FollowingStatus (Detail) VALUES ('Scope/Survey-现场审查');
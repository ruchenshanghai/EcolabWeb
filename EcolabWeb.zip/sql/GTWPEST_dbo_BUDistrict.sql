INSERT INTO GTWPEST.dbo.BUDistrict (Name) VALUES ('东北');
INSERT INTO GTWPEST.dbo.BUDistrict (Name) VALUES ('华北');
INSERT INTO GTWPEST.dbo.BUDistrict (Name) VALUES ('中区');
INSERT INTO GTWPEST.dbo.BUDistrict (Name) VALUES ('南区');
INSERT INTO GTWPEST.dbo.BUDistrict (Name) VALUES ('东区');
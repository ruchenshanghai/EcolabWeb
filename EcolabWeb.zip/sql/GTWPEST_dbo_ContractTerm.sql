INSERT INTO GTWPEST.dbo.ContractTerm (Detail) VALUES ('一次性');
INSERT INTO GTWPEST.dbo.ContractTerm (Detail) VALUES ('1年');
INSERT INTO GTWPEST.dbo.ContractTerm (Detail) VALUES ('2年');
INSERT INTO GTWPEST.dbo.ContractTerm (Detail) VALUES ('3年');
INSERT INTO GTWPEST.dbo.ContractTerm (Detail) VALUES ('自动续约');
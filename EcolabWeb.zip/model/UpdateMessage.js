/**
 * Created by wenja on 2017/6/26.
 */
function UpdateMessage() {
    this.ReviewerID = 0;
    this.BUDistrictID = 0;
    this.Province = '';
    this.City = '';
    this.Site = '';
    this.ChineseName = '';
    this.EnglishName = '';
    this.PipelineStatusID = 0;
    this.ContractTermID = 0;
    this.TargetRateID = 0;
    this.AnnualSales = 0;
    this.CorporateAccountChinese = '';
    this.CorporateAccountEnglish = '';
    this.SalesRep = '';
    this.AssistCAMNameID = 0;
    this.FollowingStatusID = 0;
    this.CTCBUID = 0;
    this.CTCSales = '';
    this.SalesTypeID = 0;
    this.FollowingStatusRemark = '';
    this.CompetitorCNID = 0;
    this.FirstCollaborationDate = '2017-06-26';
    this.EstimatedPCO = 0;
    this.Remark = '';
    this.MarketClassificationID = 0;
}

module.exports = UpdateMessage;
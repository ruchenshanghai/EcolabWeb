/**
 * Created by wenja on 2017/6/21.
 */
module.exports = {
    hostname: 'http://localhost',
    port: 2017,
    userName: 'Wenja',
    password: 'Ecolab2017',
    server: 'ruchenshanghai.database.chinacloudapi.cn',
    options: {
        database: 'Ecolab',
        encrypt: true
    }
};